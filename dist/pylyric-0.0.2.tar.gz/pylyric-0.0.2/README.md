#Pylyric
version 0.0.1

This is a module to scrape lyrics and perform sentiment analysis based on the user inputs.

------INSTRUCTIONS------

---1. INSTALLATION -----

Use command :

>pip install pylyric 

---2. USAGE ------------

The package should be imported first by typing as follow
>import pylyric.plot as pp


To use enter the following
>pp.pl_draw()

DISCLAIMER: The time for results are dependent on the internet speed.
--------THE END---------